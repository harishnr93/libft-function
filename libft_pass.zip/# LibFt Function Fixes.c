# LibFt Function Fixes

## 1. ft_bzero
**Issue**: Only zeroing the first byte instead of all `n` bytes.

**Current behavior**: `^@eeee` (only first byte zeroed)  
**Expected**: `^@^@^@^@^@` (all 5 bytes zeroed)

```c
void ft_bzero(void *s, size_t n)
{
    unsigned char *ptr = (unsigned char *)s;
    size_t i = 0;
    
    while (i < n)
    {
        ptr[i] = 0;
        i++;
    }
}
```

## 2. ft_memmove
**Issue**: Function is returning NULL or not working at all.

**Problem**: All tests show empty output, suggesting the function isn't implemented or has serious issues.

```c
void *ft_memmove(void *dest, const void *src, size_t n)
{
    unsigned char *d = (unsigned char *)dest;
    const unsigned char *s = (const unsigned char *)src;
    size_t i;
    
    if (dest == src || n == 0)
        return (dest);
    
    if (d < s)
    {
        // Copy forward
        i = 0;
        while (i < n)
        {
            d[i] = s[i];
            i++;
        }
    }
    else
    {
        // Copy backward to handle overlap
        i = n;
        while (i > 0)
        {
            i--;
            d[i] = s[i];
        }
    }
    return (dest);
}
```

## 3. ft_toupper
**Issue**: Your function is adding 32 to ALL characters instead of only lowercase letters.

**Problem**: Characters like '0' (48) become 'P' (80), when they should stay '0'.

```c
int ft_toupper(int c)
{
    if (c >= 'a' && c <= 'z')
        return (c - 32);
    return (c);
}
```

## 4. ft_tolower
**Issue**: Your function is subtracting 32 from ALL characters instead of only uppercase letters.

**Problem**: Characters are being converted incorrectly.

```c
int ft_tolower(int c)
{
    if (c >= 'A' && c <= 'Z')
        return (c + 32);
    return (c);
}
```

## 5. ft_strchr
**Issue**: Not handling the null terminator (`'\0'`) case properly.

**Problem**: Should return pointer to null terminator, not NULL.

```c
char *ft_strchr(const char *s, int c)
{
    while (*s)
    {
        if (*s == (char)c)
            return ((char *)s);
        s++;
    }
    if ((char)c == '\0')
        return ((char *)s);
    return (NULL);
}
```

## 6. ft_strrchr
**Issue**: Function appears to be returning NULL for all cases.

**Problem**: Need to search from the end or track the last occurrence.

```c
char *ft_strrchr(const char *s, int c)
{
    const char *last = NULL;
    
    while (*s)
    {
        if (*s == (char)c)
            last = s;
        s++;
    }
    if ((char)c == '\0')
        return ((char *)s);
    return ((char *)last);
}
```

## 7. ft_memchr
**Issue**: Not properly handling the byte search in memory.

**Problem**: Should treat memory as unsigned char array, not assume string format.

```c
void *ft_memchr(const void *s, int c, size_t n)
{
    const unsigned char *ptr = (const unsigned char *)s;
    size_t i = 0;
    
    while (i < n)
    {
        if (ptr[i] == (unsigned char)c)
            return ((void *)(ptr + i));
        i++;
    }
    return (NULL);
}
```

## 8. ft_memcmp
**Issue**: Not returning proper comparison values or not printing results.

**Problem**: Function should return difference between first differing bytes.

```c
int ft_memcmp(const void *s1, const void *s2, size_t n)
{
    const unsigned char *p1 = (const unsigned char *)s1;
    const unsigned char *p2 = (const unsigned char *)s2;
    size_t i = 0;
    
    while (i < n)
    {
        if (p1[i] != p2[i])
            return (p1[i] - p2[i]);
        i++;
    }
    return (0);
}
```

## 9. ft_strnstr
**Issue**: Function is returning NULL for all cases or empty output.

**Problem**: Need to properly implement substring search within length limit.

```c
char *ft_strnstr(const char *haystack, const char *needle, size_t len)
{
    size_t i, j;
    
    if (*needle == '\0')
        return ((char *)haystack);
    
    i = 0;
    while (haystack[i] && i < len)
    {
        j = 0;
        while (haystack[i + j] == needle[j] && i + j < len && needle[j])
            j++;
        if (needle[j] == '\0')
            return ((char *)&haystack[i]);
        i++;
    }
    return (NULL);
}
```

## 10. ft_strjoin
**Issue**: Function is returning NULL or empty strings.

**Problem**: Memory allocation or string copying issues.

```c
char *ft_strjoin(char const *s1, char const *s2)
{
    char *result;
    size_t i, j;
    size_t len1, len2;
    
    if (!s1 || !s2)
        return (NULL);
    
    len1 = ft_strlen(s1);
    len2 = ft_strlen(s2);
    
    result = (char *)malloc(len1 + len2 + 1);
    if (!result)
        return (NULL);
    
    i = 0;
    while (s1[i])
    {
        result[i] = s1[i];
        i++;
    }
    
    j = 0;
    while (s2[j])
    {
        result[i + j] = s2[j];
        j++;
    }
    
    result[i + j] = '\0';
    return (result);
}
```

## Key Points to Remember:

1. **Always check edge cases**: null pointers, empty strings, zero lengths
2. **Handle null terminators properly**: especially in strchr and strrchr
3. **Use unsigned char for memory operations**: prevents signed char issues
4. **Return correct values**: functions should return what they promise
5. **Test with different inputs**: including edge cases and boundary conditions

## Common Mistakes:
- Applying transformations to all characters instead of specific ranges
- Not handling null terminators in search functions
- Memory allocation failures in string functions
- Incorrect pointer arithmetic
- Not returning the original destination pointer in memory functions


*************


# LibFt Error Analysis and Fixes

## Error Analysis Summary

Your code has several critical bugs causing segmentation faults, timeouts, and memory corruption. Here's a detailed analysis:

## 1. ft_memmove - SEGMENTATION FAULT

**Problem**: You're writing to uninitialized memory (`tmp` is NULL)
```c
tmp = 0;  // tmp is NULL
tmp[i] = s[i];  // Writing to NULL pointer = SEGFAULT
```

**Root Cause**: Trying to use a temporary buffer without allocating memory for it.

**Fix**: Handle overlapping memory correctly without temporary buffer:

```c
#include <stddef.h>

void *ft_memmove(void *dst, const void *src, size_t n)
{
    unsigned char *d = (unsigned char *)dst;
    const unsigned char *s = (const unsigned char *)src;

    if (dst == src || n == 0)
        return (dst);

    if (d < s) {
        // Copy forward
        size_t i = 0;
        while (i < n) {
            d[i] = s[i];
            i++;
        }
    } else {
        // Copy backward to handle overlap
        while (n > 0) {
            n--;
            d[n] = s[n];
        }
    }
    return (dst);
}

```

## 2. ft_strrchr - TIMEOUT (INFINITE LOOP)

**Problem**: `s` is only incremented in the `else` branch
```c
if (*s == c)
    r = ((char *)s);
else
    s++;  // Only incremented here!
```

**Root Cause**: When character matches, `s` is never incremented, causing infinite loop.

**Fix**: Always increment `s`:

```c
char *ft_strrchr(const char *s, int c)
{
    char *r = NULL;
    
    while (*s) {
        if (*s == (char)c)
            r = (char *)s;
        s++;  // Always increment
    }
    if ((char)c == '\0')
        return ((char *)s);
    return (r);
}
```

## 3. ft_memchr - INCOMPLETE FUNCTION

**Problem**: Function is missing return statement and closing brace
```c
void *ft_memchr(const void *s, int c, unsigned int n)
{
    // ... code ...
    // Missing return NULL; and closing brace
```

**Fix**: Complete the function:

```c
void *ft_memchr(const void *s, int c, size_t n)
{
    const unsigned char *d = (const unsigned char *)s;
    
    while (n-- > 0) {
        if (*d == (unsigned char)c)
            return ((void *)d);
        d++;
    }
    return (NULL);
}
```

## 4. ft_memcmp - BUFFER OVERFLOW

**Problem**: Loop doesn't increment `i`, causing infinite loop and buffer overflow
```c
while (i < n) {
    if (*src1 != *src2)
        return (*src1 - *src2);
    src1++;
    src2++;
    // Missing i++!
}
```

**Fix**: Increment loop counter:

```c
int ft_memcmp(const void *s1, const void *s2, size_t n)
{
    const unsigned char *src1 = (const unsigned char *)s1;
    const unsigned char *src2 = (const unsigned char *)s2;
    size_t i = 0;
    
    while (i < n) {
        if (src1[i] != src2[i])
            return (src1[i] - src2[i]);
        i++;
    }
    return (0);
}
```

## 5. ft_strnstr - TIMEOUT (INFINITE LOOP)

**Problem**: Loop counter `i` is never incremented
```c
while (i <= len - nlen) {
    // ... code ...
    // Missing i++!
}
```

**Fix**: Increment loop counter and handle edge cases:

```c
char *ft_strnstr(const char *haystack, const char *needle, size_t len)
{
    size_t nlen;
    size_t i;
    
    if (*needle == '\0')
        return ((char *)haystack);
    if (*haystack == '\0' || len == 0)
        return (NULL);
    
    nlen = ft_strlen(needle);
    if (nlen > len)
        return (NULL);
    
    i = 0;
    while (i <= len - nlen) {
        if (haystack[i] == needle[0]) {
            if (ft_strncmp(haystack + i, needle, nlen) == 0)
                return ((char *)&haystack[i]);
        }
        i++;  // Critical: increment counter
    }
    return (NULL);
}
```

## 6. ft_strjoin - HEAP BUFFER OVERFLOW

**Problem**: Wrong loop conditions and index usage
```c
while (s1)       // Should be while (s1[j])
    pstr[i++] = s1[j];  // j is never incremented!
```

**Root Cause**: 
- `while (s1)` is always true (pointer is not NULL)
- `j` is never incremented, always reading `s1[0]`
- Writing beyond allocated memory

**Fix**: Proper loop conditions and index management:

```c
char *ft_strjoin(char const *s1, char const *s2)
{
    size_t s1len, s2len;
    size_t i, j;
    char *pstr;
    
    if (!s1 || !s2)
        return (NULL);
    
    s1len = ft_strlen(s1);
    s2len = ft_strlen(s2);
    
    pstr = ft_calloc(s1len + s2len + 1, sizeof(char));
    if (!pstr)
        return (NULL);
    
    i = 0;
    j = 0;
    while (j < s1len) {
        pstr[i++] = s1[j++];
    }
    
    j = 0;
    while (j < s2len) {
        pstr[i++] = s2[j++];
    }
    
    pstr[i] = '\0';
    return (pstr);
}
```

## Complete Fixed Code

```c
// ft_memmove.c
void *ft_memmove(void *dst, const void *src, size_t n)
{
    unsigned char *d = (unsigned char *)dst;
    const unsigned char *s = (const unsigned char *)src;
    
    if (dst == src || n == 0)
        return (dst);
    
    if (d < s) {
        for (size_t i = 0; i < n; i++)
            d[i] = s[i];
    } else {
        for (size_t i = n; i > 0; i--)
            d[i - 1] = s[i - 1];
    }
    return (dst);
}

// ft_strrchr.c
char *ft_strrchr(const char *s, int c)
{
    char *r = NULL;
    
    while (*s) {
        if (*s == (char)c)
            r = (char *)s;
        s++;
    }
    if ((char)c == '\0')
        return ((char *)s);
    return (r);
}

// ft_memchr.c
void *ft_memchr(const void *s, int c, size_t n)
{
    const unsigned char *d = (const unsigned char *)s;
    
    while (n-- > 0) {
        if (*d == (unsigned char)c)
            return ((void *)d);
        d++;
    }
    return (NULL);
}

// ft_memcmp.c
int ft_memcmp(const void *s1, const void *s2, size_t n)
{
    const unsigned char *src1 = (const unsigned char *)s1;
    const unsigned char *src2 = (const unsigned char *)s2;
    size_t i = 0;
    
    while (i < n) {
        if (src1[i] != src2[i])
            return (src1[i] - src2[i]);
        i++;
    }
    return (0);
}

// ft_strnstr.c
char *ft_strnstr(const char *haystack, const char *needle, size_t len)
{
    size_t nlen;
    size_t i;
    
    if (*needle == '\0')
        return ((char *)haystack);
    if (*haystack == '\0' || len == 0)
        return (NULL);
    
    nlen = ft_strlen(needle);
    if (nlen > len)
        return (NULL);
    
    i = 0;
    while (i <= len - nlen) {
        if (haystack[i] == needle[0]) {
            if (ft_strncmp(haystack + i, needle, nlen) == 0)
                return ((char *)&haystack[i]);
        }
        i++;
    }
    return (NULL);
}

// ft_strjoin.c
char *ft_strjoin(char const *s1, char const *s2)
{
    size_t s1len, s2len;
    size_t i, j;
    char *pstr;
    
    if (!s1 || !s2)
        return (NULL);
    
    s1len = ft_strlen(s1);
    s2len = ft_strlen(s2);
    
    pstr = ft_calloc(s1len + s2len + 1, sizeof(char));
    if (!pstr)
        return (NULL);
    
    i = 0;
    j = 0;
    while (j < s1len) {
        pstr[i++] = s1[j++];
    }
    
    j = 0;
    while (j < s2len) {
        pstr[i++] = s2[j++];
    }
    
    pstr[i] = '\0';
    return (pstr);
}
```

## Key Lessons

1. **Always increment loop counters** - Missing increments cause infinite loops
2. **Check for NULL pointers** - Don't dereference uninitialized pointers
3. **Handle edge cases** - Empty strings, zero lengths, NULL inputs
4. **Proper memory management** - Don't write beyond allocated bounds
5. **Complete your functions** - Missing return statements cause undefined behavior

## Testing Recommendations

1. Test with empty strings and NULL inputs
2. Test boundary conditions (len = 0, len = 1)
3. Test overlapping memory regions for memmove
4. Use AddressSanitizer (`-fsanitize=address`) to catch memory errors
5. Test with valgrind for memory leaks