/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hnataraj <hnataraj@student.42heilbronn.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/08 17:04:24 by hnataraj          #+#    #+#             */
/*   Updated: 2025/07/11 15:03:37 by hnataraj         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	*ft_memchr(const void *s, int c, unsigned int n)
{
	const unsigned char	*d = (const unsigned char *)s;

	while (n-- > 0)
	{
		if (*d == c)
			return ((void *)d);
		d++;
	}
	return (0);
}
